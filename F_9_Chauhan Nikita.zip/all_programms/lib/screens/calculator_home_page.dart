import 'package:flutter/material.dart';
import 'package:math_expressions/math_expressions.dart';

class CalculatorHomePage extends StatefulWidget {
  @override
  _CalculatorHomePageState createState() => _CalculatorHomePageState();
}

class _CalculatorHomePageState extends State<CalculatorHomePage> {
  String expression = ""; // Current expression
  String result = "0"; // Result of the expression

  // Method to handle button presses
  void onButtonPressed(String value) {
    setState(() {
      if (value == "C") {
        // Clear expression and result
        expression = "";
        result = "0";
      } else if (value == "=") {
        // Evaluate the expression
        try {
          Parser p = Parser();
          Expression exp = p.parse(expression);
          ContextModel cm = ContextModel();
          result = '${exp.evaluate(EvaluationType.REAL, cm)}';
        } catch (e) {
          result = "Error";
        }
      } else {
        // Add value to the expression
        expression += value;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    // Get screen size for responsive design
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;

    // Button size based on screen width
    double buttonSize = screenWidth / 4; // 4 buttons per row
    double buttonTextSize = screenWidth * 0.06; // Button text size relative to screen width
    double resultTextSize = screenHeight * 0.06; // Result text size relative to screen height

    return Scaffold(
      appBar: AppBar(title: Text('Responsive Calculator')),
      body: Column(
        children: [
          // Display the current expression and result
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(16.0),
            color: Colors.grey[200],
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  expression,
                  style: TextStyle(fontSize: resultTextSize, color: Colors.black54),
                  textAlign: TextAlign.right,
                ),
                Text(
                  result,
                  style: TextStyle(fontSize: resultTextSize * 1.5, color: Colors.black),
                  textAlign: TextAlign.right,
                ),
              ],
            ),
          ),
          Expanded(
            child: GridView.builder(
              itemCount: 20,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4, // 4 buttons per row
                childAspectRatio: 1, // Make buttons square
              ),
              itemBuilder: (context, index) {
                List<String> buttons = [
                  '7', '8', '9', '/',
                  '4', '5', '6', '*',
                  '1', '2', '3', '-',
                  '0', '.', '=', '+',
                  'C', '(', ')', 'Del'
                ];
                String buttonLabel = buttons[index];

                return Container(
                  margin: EdgeInsets.all(8.0),
                  child: ElevatedButton(
                    onPressed: () {
                      if (buttonLabel == "Del" && expression.isNotEmpty) {
                        setState(() {
                          expression = expression.substring(0, expression.length - 1);
                        });
                      } else if (buttonLabel != "Del") {
                        onButtonPressed(buttonLabel);
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12.0),
                      ),
                      padding: EdgeInsets.all(0),
                      minimumSize: Size(buttonSize, buttonSize), // Set button size
                    ),
                    child: Text(
                      buttonLabel,
                      style: TextStyle(fontSize: buttonTextSize),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: CalculatorHomePage(),
  ));
}
